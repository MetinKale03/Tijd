package com.example.test_tijd;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView result;
    EditText StartTime, EndTime;
    Button Bereken;

    int ResultNum;
    int num1,num2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        result=(TextView) findViewById(R.id.txtVerschil);
        StartTime=(EditText) findViewById(R.id.StartTime);
        EndTime=(EditText) findViewById(R.id.EndTime);
        Bereken=(Button) findViewById(R.id.btnCalc);

        Bereken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                num1=Integer.parseInt(StartTime.getText().toString());
                num2=Integer.parseInt(EndTime.getText().toString());
                if(num1>24||num2>24){
                    result.setText("max waarde is 24");
                }
                else{
                    ResultNum=num2-num1;
                    result.setText(String.valueOf(ResultNum)+" uur");
                }


            }
        });
    }


}